import React from 'react';
import Header from './components/Header';
import ProtocolInfo from './components/ProtocolInfo';
import ResortDirectory from './components/ResortDirectory';
import LexiconLab from './components/LexiconLab';
import CollaboratorSpace from './components/CollaboratorSpace';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="min-h-screen selection:bg-emerald-500/30 selection:text-emerald-200">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 pt-32 pb-24 space-y-24">
        {/* Intro Section */}
        <section className="space-y-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-mono font-bold text-emerald-500 uppercase tracking-[0.2em]"
          >
            Decentralized Shred Intelligence
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold tracking-tight text-white leading-[0.95]"
          >
            Federating the <span className="text-emerald-500">World's Slopes.</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-slate-400 font-light leading-relaxed max-w-2xl"
          >
            A global, open-source database of ski and snowboard resorts, built to interface with the AT Protocol's social substrate.
          </motion.p>
        </section>

        {/* Overview & Grid */}
        <ProtocolInfo />
        
        {/* Resorts */}
        <ResortDirectory />

        {/* Lexicon Lab */}
        <LexiconLab />

        {/* V's Section */}
        <CollaboratorSpace />
        
        <footer className="pt-12 border-t border-emerald-500/10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4 text-[10px] font-mono text-slate-500 uppercase tracking-widest">
            <span>By V & Gem</span>
            <span className="w-1 h-1 bg-emerald-500 rounded-full" />
            <span>Built for the AT Protocol Community</span>
          </div>
          <div className="flex items-center gap-6 text-slate-600">
            <span className="text-[10px] uppercase tracking-tighter opacity-50">Repo: toltech.io</span>
            <a href="https://atproto.com" className="hover:text-emerald-400 transition-colors">ATProto Specs</a>
          </div>
        </footer>
      </main>

      {/* Decorative background grid */}
      <div className="fixed inset-0 pointer-events-none z-[-1] opacity-[0.03]" 
           style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #10b981 1px, transparent 0)', backgroundSize: '40px 40px' }} />
    </div>
  );
}
