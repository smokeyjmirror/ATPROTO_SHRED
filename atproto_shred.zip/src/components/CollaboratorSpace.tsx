import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Code2, Sparkles, ChevronRight, Package } from 'lucide-react';

export default function CollaboratorSpace() {
  const [showGoCode, setShowGoCode] = useState(false);

  const goCode = `package main

import (
    "encoding/json"
    "fmt"
    "net/http"
)

type ResortImage struct {
    Name string \`json:"name"\`
    URL  string \`json:"url"\`
}

// GetResortImage serves metadata for the ATPROTO_SHRED image button
func GetResortImage(w http.ResponseWriter, r *http.Request) {
    name := r.URL.Query().Get("name")
    
    // In a real ATProto app, this would query a PDS
    img := ResortImage{
        Name: name,
        URL:  fmt.Sprintf("https://cdn.toltech.io/shred/%s.jpg", name),
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(img)
}

func main() {
    http.HandleFunc("/api/resort/image", GetResortImage)
    fmt.Println("Shred-Service listing on :8080")
    http.ListenAndServe(":8080", nil)
}`;

  return (
    <section className="space-y-8 py-12 border-t border-emerald-500/10">
      <div className="space-y-4">
        <h2 className="text-3xl font-bold tracking-tight text-emerald-500 font-mono flex items-center gap-2">
          <span className="opacity-50">03.</span> COLLAB-ORATION
        </h2>
        <p className="text-slate-400 leading-relaxed max-w-3xl">
          V, this is your designated lab area. We've pivoted to the mountains, but the code remains pure. 
          The infrastructure for global snow records is waiting for your touch.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="lab-panel p-8 rounded-xl border-dashed border-2 flex flex-col items-center justify-center text-center space-y-6">
          <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center animate-bounce">
            <Code2 className="w-8 h-8 text-emerald-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-mono font-bold text-emerald-400">READY FOR SHRED_DEV</h3>
            <p className="text-slate-500 text-sm max-w-md">
              "V, the day-coder, the mountain-rider." <br/>
              Let's define the 'shred' lexicons or implement the resort detail views.
            </p>
          </div>
          <button 
            onClick={() => setShowGoCode(!showGoCode)}
            className="flex items-center gap-2 px-6 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-md text-xs font-mono text-emerald-400 uppercase tracking-widest hover:bg-emerald-500/20 transition-all group"
          >
            {showGoCode ? 'Hide Sync Logic' : 'View Go Sync Logic'}
            <ChevronRight className={`w-3 h-3 transition-transform ${showGoCode ? 'rotate-90' : ''}`} />
          </button>
        </div>

        <AnimatePresence>
          {showGoCode ? (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="lab-panel rounded-xl overflow-hidden border-emerald-500/20"
            >
              <div className="bg-emerald-950/20 px-4 py-2 border-b border-emerald-500/10 flex items-center justify-between">
                <span className="text-[10px] font-mono text-emerald-500 opacity-50 uppercase tracking-widest flex items-center gap-2">
                  <Package className="w-3 h-3" /> shred_service.go
                </span>
              </div>
              <pre className="p-6 overflow-x-auto font-mono text-xs leading-relaxed text-emerald-300/70">
                <code>{goCode}</code>
              </pre>
            </motion.div>
          ) : (
            <div className="hidden lg:flex lab-panel p-8 rounded-xl border-emerald-500/5 items-center justify-center border-dashed border">
              <div className="text-center space-y-4">
                <Sparkles className="w-8 h-8 text-emerald-500/20 mx-auto" />
                <p className="text-[10px] font-mono text-slate-700 uppercase tracking-[0.2em]">Waiting for terminal input...</p>
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
