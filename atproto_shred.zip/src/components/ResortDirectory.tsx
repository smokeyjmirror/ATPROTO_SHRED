import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Mountain, Wind, Snowflake, Info, Image as ImageIcon, X } from 'lucide-react';
import { resorts, Resort } from '../data/resortsData';

const getIcon = (type: "snowflake" | "mountain" | "wind") => {
  switch (type) {
    case "snowflake":
      return <Snowflake className="w-4 h-4 text-blue-300" />;
    case "mountain":
      return <Mountain className="w-4 h-4 text-emerald-400" />;
    case "wind":
    default:
      return <Wind className="w-4 h-4 text-slate-300" />;
  }
};

export default function ResortDirectory() {
  const [selectedResort, setSelectedResort] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedContinent, setSelectedContinent] = useState("All");
  const [visibleCount, setVisibleCount] = useState(12);

  const resortDetails = resorts.find(r => r.name === selectedResort);

  const filteredResorts = resorts.filter(resort => {
    const matchesContinent = selectedContinent === "All" || resort.continent === selectedContinent;
    const matchesSearch = resort.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          resort.region.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          resort.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          resort.country.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesContinent && matchesSearch;
  });

  const displayedResorts = filteredResorts.slice(0, visibleCount);
  const hasMore = visibleCount < filteredResorts.length;

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 12);
  };

  return (
    <section id="resorts-section" className="space-y-8 relative">
      <AnimatePresence>
        {selectedResort && resortDetails && (
          <motion.div 
            id="modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md"
            onClick={() => setSelectedResort(null)}
          >
            <motion.div 
              id="modal-panel"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="lab-panel max-w-lg w-full rounded-2xl overflow-hidden relative"
              onClick={e => e.stopPropagation()}
            >
              <button 
                id="close-modal-btn"
                onClick={() => setSelectedResort(null)}
                className="absolute top-4 right-4 z-10 p-2 bg-black/40 hover:bg-black/60 rounded-full text-white transition-colors"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="aspect-video w-full overflow-hidden">
                <img 
                  id="modal-resort-img"
                  src={resortDetails.image} 
                  alt={resortDetails.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-8 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-500/10 rounded-lg">
                    {getIcon(resortDetails.iconType)}
                  </div>
                  <div>
                    <h3 id="modal-resort-title" className="text-2xl font-mono font-bold text-emerald-400">{resortDetails.name}</h3>
                    <p id="modal-resort-sub" className="text-xs text-slate-500 uppercase tracking-widest">{resortDetails.region}, {resortDetails.country}</p>
                  </div>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed">
                  Historical shred data verified on the AT Protocol. This node serves verified terrain and vertical 
                  displacement statistics for {resortDetails.name}.
                </p>
                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center border-b border-emerald-500/10 pb-1">
                      <span className="text-[10px] uppercase font-mono text-emerald-500">Chalets ({resortDetails.chalets?.total || 0})</span>
                      <span className="text-[9px] font-mono text-slate-500 uppercase">(Clickable Detail Link pending)</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {resortDetails.chalets?.names.map((chalet) => (
                        <button 
                          id={`chalet-${chalet.replace(/\s+/g, '-').toLowerCase()}`}
                          key={chalet}
                          className="px-2.5 py-1 text-xs font-mono bg-emerald-500/5 hover:bg-emerald-500/15 border border-emerald-500/20 rounded text-emerald-400 transition-all cursor-pointer select-none text-left"
                          title="View Chalet Details (Coming Soon)"
                        >
                          {chalet}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <div className="flex justify-between items-center border-b border-emerald-500/10 pb-1">
                      <span className="text-[10px] uppercase font-mono text-emerald-500">Lifts & Gondolas ({resortDetails.lifts?.total || 0} Total)</span>
                      <span className="text-[9px] font-mono text-slate-500 uppercase">(Clickable Detail Link pending)</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {resortDetails.lifts?.names.map((lift) => (
                        <button 
                          id={`lift-${lift.replace(/\s+/g, '-').toLowerCase()}`}
                          key={lift}
                          className="px-2.5 py-1 text-xs font-mono bg-emerald-500/5 hover:bg-emerald-500/15 border border-emerald-500/20 rounded text-emerald-400 transition-all cursor-pointer select-none text-left"
                          title="View Lift Details (Coming Soon)"
                        >
                          {lift}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        <h2 id="section-title" className="text-3xl font-bold tracking-tight text-emerald-500 font-mono flex items-center gap-2">
          <span className="opacity-50">02.</span> GLOBAL RESORTS
        </h2>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="text-slate-400 leading-relaxed max-w-2xl">
            Tracking the world's most iconic shreds through the lens of decentralized data. Currently indexing {resorts.length} major global resorts.
          </p>
          <div className="text-xs font-mono text-slate-500 uppercase tracking-widest bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded">
            DB Count: {filteredResorts.length} found
          </div>
        </div>
      </div>

      {/* Modern, high-contrast Search & Filtering interface */}
      <div id="search-filter-controls" className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center p-4 bg-slate-900/40 border border-emerald-500/10 rounded-xl">
        <div className="relative flex-1 max-w-md">
          <input
            id="resort-search-input"
            type="text"
            className="w-full px-4 py-2 bg-slate-950 border border-emerald-500/20 rounded-md text-emerald-400 placeholder-slate-600 font-mono text-sm focus:outline-none focus:border-emerald-500/60 transition-all"
            placeholder="Search resort, region, or country..."
            value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              setVisibleCount(12);
            }}
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {["All", "North America", "Europe", "Asia", "South America", "Oceania"].map(continent => (
            <button
              id={`filter-${continent.replace(/\s+/g, '-').toLowerCase()}`}
              key={continent}
              onClick={() => {
                setSelectedContinent(continent);
                setVisibleCount(12);
              }}
              className={`px-3 py-1.5 text-[10px] font-mono rounded border transition-all cursor-pointer ${
                selectedContinent === continent
                  ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-400 font-bold"
                  : "bg-slate-950 border-slate-800 text-slate-500 hover:text-emerald-400 hover:border-emerald-500/20"
              }`}
            >
              {continent.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Resorts Grid */}
      <div id="resorts-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {displayedResorts.map((resort, i) => (
          <motion.div 
            id={`resort-card-${resort.name.replace(/\s+/g, '-').toLowerCase()}`}
            key={resort.name}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: (i % 6) * 0.05 }}
            className="lab-panel p-5 rounded-lg border-l-2 border-l-emerald-500/30 flex flex-col justify-between group bg-slate-900/20 hover:bg-slate-900/40 transition-all duration-300"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 font-mono font-bold text-emerald-400 tracking-tight">
                  {getIcon(resort.iconType)}
                  {resort.name.toUpperCase()}
                </span>
                <div className="flex items-center gap-2">
                  <button 
                    id={`view-image-btn-${resort.name.replace(/\s+/g, '-').toLowerCase()}`}
                    onClick={() => setSelectedResort(resort.name)}
                    className="p-1.5 hover:bg-emerald-500/10 rounded-md transition-colors text-slate-600 hover:text-emerald-400 cursor-pointer"
                    title="View Image, Chalets & Lifts"
                  >
                    <ImageIcon className="w-4 h-4" />
                  </button>
                  <Info className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition-colors cursor-help" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-y-2 text-[10px] font-mono tracking-wider uppercase">
                <div className="text-slate-600">Region</div>
                <div className="text-slate-400 truncate">{resort.region}</div>
                
                <div className="text-slate-600">Location</div>
                <div className="text-slate-400 truncate">{resort.state}, {resort.country}</div>
                
                <div className="text-slate-600">Continent</div>
                <div className="text-emerald-500/70">{resort.continent}</div>

                <div className="text-slate-600">Vertical</div>
                <div className="text-slate-400 font-bold">{resort.vertical.toLocaleString()} FT</div>
              </div>

              {/* Terrain Stats Section */}
              <div className="flex items-center gap-3 pt-4 border-t border-emerald-500/10">
                <div className="flex items-center gap-1.5" title="Beginner (Green)">
                  <div className="w-2 h-2 bg-green-500 flex-shrink-0" />
                  <span className="text-[10px] font-mono text-slate-500">{resort.terrain.green}</span>
                </div>
                <div className="flex items-center gap-1.5" title="Intermediate (Blue)">
                  <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                  <span className="text-[10px] font-mono text-slate-500">{resort.terrain.blue}</span>
                </div>
                <div className="flex items-center gap-1.5" title="Difficult (Black)">
                  <div className="w-2 h-2 bg-slate-200 rotate-45 flex-shrink-0" />
                  <span className="text-[10px] font-mono text-slate-500">{resort.terrain.black}</span>
                </div>
                <div className="ml-auto text-[10px] font-mono text-emerald-500/60 font-bold uppercase tracking-tighter">
                  {resort.terrain.total} TOTAL RUNS
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-emerald-500/5 flex items-center gap-2">
               <div className="w-full h-1 bg-emerald-500/10 rounded-full overflow-hidden">
                 <div className="w-1/3 h-full bg-emerald-500/40 animate-pulse" />
               </div>
               <span className="text-[8px] font-mono text-slate-700 whitespace-nowrap uppercase">Syncing Records...</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div id="load-more-container" className="flex justify-center pt-8">
          <button
            id="load-more-btn"
            onClick={handleLoadMore}
            className="px-6 py-2.5 bg-slate-900 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500/50 text-emerald-400 font-mono text-xs uppercase tracking-widest rounded transition-all cursor-pointer shadow"
          >
            Load More Resorts ({filteredResorts.length - visibleCount} remaining)
          </button>
        </div>
      )}

      {/* Helpful empty state */}
      {filteredResorts.length === 0 && (
        <div id="no-resorts-alert" className="text-center py-12 border border-dashed border-emerald-500/10 rounded-lg">
          <p className="text-slate-500 font-mono text-sm uppercase tracking-wider">No shreds matching query active on this node.</p>
        </div>
      )}
    </section>
  );
}
