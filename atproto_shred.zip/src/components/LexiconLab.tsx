import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Fingerprint, Database, Code, BookOpen, ChevronRight, Braces } from 'lucide-react';
import { cn } from '../lib/utils';

export default function LexiconLab() {
  const [activeTab, setActiveTab] = useState<'lexicon' | 'identity' | 'signing'>('lexicon');

  const lexiconCode = `{
  "lexicon": 1,
  "id": "io.toltech.shred.resort",
  "defs": {
    "main": {
      "type": "record",
      "description": "A record of a ski resort",
      "key": "tid",
      "record": {
        "type": "object",
        "required": ["name", "location", "vertical", "runs", "lifts", "chalets"],
        "properties": {
          "name": { "type": "string", "maxLen": 100 },
          "location": { "$ref": "#location" },
          "vertical": { "type": "integer", "description": "Vertical drop in feet" },
          "runs": { "$ref": "#runsList" },
          "lifts": { "$ref": "#liftsList" },
          "chalets": { "$ref": "#chaletsList" },
          "terrain": { "$ref": "#terrainStats" }
        }
      }
    },
    "location": {
      "type": "object",
      "required": ["continent", "country", "state"],
      "properties": {
        "continent": { "type": "string" },
        "country": { "type": "string" },
        "state": { "type": "string" },
        "region": { "type": "string" }
      }
    },
    "terrainStats": {
      "type": "object",
      "required": ["total", "green", "blue", "black"],
      "properties": {
        "total": { "type": "integer" },
        "green": { "type": "integer" },
        "blue": { "type": "integer" },
        "black": { "type": "integer" }
      }
    },
    "runsList": {
      "type": "object",
      "required": ["total", "difficultyBreakdown"],
      "properties": {
        "total": { "type": "integer" },
        "difficultyBreakdown": { "type": "array", "items": { "$ref": "#runDetail" } }
      }
    },
    "runDetail": {
      "type": "object",
      "required": ["name", "difficulty", "lengthMeters"],
      "properties": {
        "name": { "type": "string" },
        "difficulty": { "type": "string", "knownValues": ["green", "blue", "black", "double-black"] },
        "lengthMeters": { "type": "integer" }
      }
    },
    "liftsList": {
      "type": "object",
      "required": ["total"],
      "properties": {
        "total": { "type": "integer" },
        "gondolas": { "type": "integer" },
        "chairlifts": { "type": "integer" },
        "tBars": { "type": "integer" }
      }
    },
    "chaletsList": {
      "type": "object",
      "required": ["total", "chalets"],
      "properties": {
        "total": { "type": "integer" },
        "chalets": { "type": "array", "items": { "$ref": "#chaletDetail" } }
      }
    },
    "chaletDetail": {
      "type": "object",
      "required": ["name", "elevationMeters"],
      "properties": {
        "name": { "type": "string" },
        "elevationMeters": { "type": "integer" },
        "capacity": { "type": "integer" },
        "hasDining": { "type": "boolean" }
      }
    }
  }
}`;

  const identityPseudocode = `// ATProto Identity Resolution
async function resolveV() {
  // 1. Resolve Handle to DID
  const did = await atproto.resolveHandle('smokeyjmirror.toltech.io'); 
  // did:plc:4vshred777...

  // 2. Resolve DID to PDS (Personal Data Server)
  const doc = await did.resolveDocument(did);
  console.log("V's Data lives at:", doc.service[0].serviceEndpoint);
  // https://pds.toltech.io
}`;

  const signingPseudocode = `// Creating a Signed Record
const shredRecord = {
  $type: 'io.toltech.shred.resort',
  name: 'A-Basin',
  location: 'Colorado',
  createdAt: new Date().toISOString()
};

// The PDS signs the record with your Private Key
const signed = await agent.api.com.atproto.repo.createRecord({
  repo: 'smokeyjmirror.toltech.io',
  collection: 'io.toltech.shred.resort',
  record: shredRecord
});

console.log("Record Integrity CID:", signed.cid);`;

  return (
    <section className="space-y-8 py-12 border-t border-emerald-500/10">
      <div className="space-y-4">
        <h2 className="text-3xl font-bold tracking-tight text-emerald-500 font-mono flex items-center gap-2">
          <span className="opacity-50">04.</span> COMPLIANCE_LAB
        </h2>
        <p className="text-slate-400 leading-relaxed max-w-3xl">
          Understanding the plumbing. Here is how we turn "Resort Data" into "AT Protocol Records."
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-3 space-y-2">
          <button 
            onClick={() => setActiveTab('lexicon')}
            className={cn(
              "w-full text-left px-4 py-3 rounded-lg font-mono text-xs uppercase tracking-widest border transition-all flex items-center justify-between group",
              activeTab === 'lexicon' ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-400" : "bg-transparent border-emerald-500/10 text-slate-500 hover:border-emerald-500/30"
            )}
          >
            <div className="flex items-center gap-3">
              <BookOpen className="w-4 h-4" />
              <span>Lexicon Schema</span>
            </div>
            <ChevronRight className={cn("w-3 h-3 transition-transform", activeTab === 'lexicon' ? "rotate-90" : "")} />
          </button>

          <button 
            onClick={() => setActiveTab('identity')}
            className={cn(
              "w-full text-left px-4 py-3 rounded-lg font-mono text-xs uppercase tracking-widest border transition-all flex items-center justify-between group",
              activeTab === 'identity' ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-400" : "bg-transparent border-emerald-500/10 text-slate-500 hover:border-emerald-500/30"
            )}
          >
            <div className="flex items-center gap-3">
              <Fingerprint className="w-4 h-4" />
              <span>Identity (DID)</span>
            </div>
            <ChevronRight className={cn("w-3 h-3 transition-transform", activeTab === 'identity' ? "rotate-90" : "")} />
          </button>

          <button 
            onClick={() => setActiveTab('signing')}
            className={cn(
              "w-full text-left px-4 py-3 rounded-lg font-mono text-xs uppercase tracking-widest border transition-all flex items-center justify-between group",
              activeTab === 'signing' ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-400" : "bg-transparent border-emerald-500/10 text-slate-500 hover:border-emerald-500/30"
            )}
          >
            <div className="flex items-center gap-3">
              <Database className="w-4 h-4" />
              <span>Repo Signing</span>
            </div>
            <ChevronRight className={cn("w-3 h-3 transition-transform", activeTab === 'signing' ? "rotate-90" : "")} />
          </button>
        </div>

        {/* Code View */}
        <div className="lg:col-span-9 lab-panel rounded-xl overflow-hidden border-emerald-500/20 relative">
          <div className="bg-emerald-950/20 px-4 py-2 border-b border-emerald-500/10 flex items-center justify-between">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/40" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/40" />
            </div>
            <span className="text-[10px] font-mono text-emerald-500 opacity-50 uppercase tracking-widest flex items-center gap-2">
              <Code className="w-3 h-3" /> {activeTab === 'lexicon' ? 'lexicon.json' : 'atproto_service.ts'}
            </span>
          </div>
          
          <pre className="p-6 overflow-x-auto font-mono text-sm leading-relaxed text-emerald-300/80">
            <code>
              {activeTab === 'lexicon' && lexiconCode}
              {activeTab === 'identity' && identityPseudocode}
              {activeTab === 'signing' && signingPseudocode}
            </code>
          </pre>

          {/* Decorative Glitch Overlay */}
          <div className="absolute bottom-4 right-4 text-[8px] font-mono text-emerald-900 select-none">
            {activeTab.toUpperCase()}_BLOCK_SIGNED_VERIFIED
          </div>
        </div>
      </div>
    </section>
  );
}
