import React from 'react';
import { motion } from 'motion/react';
import { Beaker, Search, Menu, Cpu } from 'lucide-react';

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 lab-panel border-t-0 border-x-0 rounded-none bg-bg-lab/80">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-emerald-500 flex items-center justify-center rounded-sm lab-glow transform rotate-45">
            <Cpu className="w-5 h-5 text-bg-lab transform -rotate-45" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-sm font-mono font-bold tracking-tighter text-emerald-500 leading-none">
              ATPROTO_SHRED
            </h1>
            <span className="text-[10px] font-mono opacity-40 uppercase tracking-widest">
              v0.1.0-alpha
            </span>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-[11px] font-mono uppercase tracking-widest text-slate-500">
          <a href="#" className="flex items-center gap-2 text-emerald-400 border-b border-emerald-500 pb-1">
            <span className="opacity-50">0x01</span> Explorer
          </a>
          <a href="#" className="hover:text-emerald-400 transition-colors">
            <span className="opacity-50">0x02</span> Documentation
          </a>
          <a href="#" className="hover:text-emerald-400 transition-colors">
            <span className="opacity-50">0x03</span> Lexicon
          </a>
        </nav>

        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-emerald-500/10 rounded-md transition-colors text-slate-400">
            <Search className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-emerald-500/10 rounded-md transition-colors text-slate-400">
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
