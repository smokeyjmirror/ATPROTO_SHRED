import React from 'react';
import { motion } from 'motion/react';
import { Activity, Shield, Share2, Layers } from 'lucide-react';

export default function ProtocolInfo() {
  const features = [
    {
      icon: <Shield className="w-5 h-5 text-emerald-400" />,
      title: "Decentralized Records",
      desc: "Every lift ticket, shred log, and terrain report stored as a signed record on your Personal Data Server (PDS). You own your mountain achievements."
    },
    {
      icon: <Activity className="w-5 h-5 text-emerald-400" />,
      title: "Open Weather Data",
      desc: "Instead of relying on proprietary resort feeds, ATPROTO_SHRED leverages community-driven lexicons for real-time snow conditions."
    },
    {
      icon: <Share2 className="w-5 h-5 text-emerald-400" />,
      title: "Cross-Resort Social",
      desc: "The protocol allows you to find your crew regardless of which mountain they are currently shredding. Your social graph is portable."
    },
    {
      icon: <Layers className="w-5 h-5 text-emerald-400" />,
      title: "The Firehose",
      desc: "A globally unified stream of 'shred events'. High-performance indexed feeds for tracking vertical feet and global lift status."
    }
  ];

  return (
    <section className="space-y-8">
      <div className="space-y-4">
        <h2 className="text-3xl font-bold tracking-tight text-emerald-500 font-mono flex items-center gap-2">
          <span className="opacity-50">01.</span> THE VISION
        </h2>
        <p className="text-slate-400 leading-relaxed max-w-3xl">
          ATPROTO_SHRED combines the decentralized power of the Authenticated Transfer (AT) Protocol with a global directory of ski and snowboard resorts. We are building the infrastructure for the open mountain web.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {features.map((f, i) => (
          <motion.div 
            key={f.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="lab-panel p-6 rounded-lg space-y-3 hover:border-emerald-500/50 transition-colors group"
          >
            <div className="p-2 bg-emerald-500/10 w-fit rounded-md group-hover:bg-emerald-500/20 transition-colors">
              {f.icon}
            </div>
            <h3 className="font-semibold text-emerald-300 font-mono uppercase text-sm tracking-widest">{f.title}</h3>
            <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
